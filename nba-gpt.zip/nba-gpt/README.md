# NBAGPT

A GPT-style transformer trained from scratch on NBA play-by-play. Each game is a sequence of event tokens (`H_3PT_MAKE`, `A_DREB`, `H_TOV`, ...), and the model learns to predict the next event and the home team's win probability at every moment of the game.

## Pipeline

```bash
pip install -r requirements.txt

python fetch_data.py --seasons 2021-22 2022-23 2023-24 2024-25   # ~5k games, a few hours, resumable
python tokenize_pbp.py                                           # -> data/processed/games.pkl
python baseline.py                                               # logistic regression on score + time
python train.py --out runs/base                                  # 4-layer, 128-dim model (~0.8M params)
python evaluate.py --ckpt runs/base/best.pt                      # metrics + plots in results/
python scaling.py                                                # model size vs. val loss
```

Test the full pipeline without the NBA API first:

```bash
python synthetic.py --games 400
python tokenize_pbp.py --raw data/raw_synthetic --out data/processed/synthetic.pkl
python baseline.py --data data/processed/synthetic.pkl
python train.py --data data/processed/synthetic.pkl --out runs/syn --n_layer 2 --n_embd 64 --n_head 2 --lr 1e-3
python evaluate.py --ckpt runs/syn/best.pt --data data/processed/synthetic.pkl --out results_syn
```

## Design

- **Tokens**: 31-token vocabulary. Events are team-relative (home/away), and offensive vs. defensive rebounds are inferred from who missed last. Substitutions and replays are dropped.
- **Game state**: time remaining, score differential, period, and lead-relative-to-time are projected into the embedding at each position, so the model doesn't have to reconstruct the score by counting baskets.
- **Model**: decoder-only transformer with causal attention, tied embeddings, and two heads: next event (cross-entropy) and home win (BCE at every position).
- **Split**: the latest season is the test set, so there's no leakage from future games.

## What to report

- Next-event perplexity and accuracy
- Win-probability Brier score vs. the logistic baseline, overall and by quarter
- Calibration plot
- Scaling curve (val loss vs. parameters)
- Win-probability charts for memorable games

## Extensions

- Player tokens or learned player embeddings (then cluster them)
- Lineup-aware win probability, possession-level expected points
- Game simulation by sampling future events
- Train on 10+ seasons and extend the scaling curve
